<?php
include './layout/header.php';
?>

<div class="c-1200">
    <div id="page-title"><h3>BEST CARE & BETTER DOCTOR</h3>
    </div>
</div>


<div class="login-form">



 
    <form action="">
        <p class="about-us">

            Health care is considered one of the necessary
            priorities in life. Human health is the most precious of
            what we have. Any person in us may be exposed to a disease.
            Therefore, we undertook this project in order to shorten the time for
            patients who suffer from long waiting and overcrowding that occurs in 
            the hospital, as through this system the patient can communicate with 
            The doctor easily and can make for the doctor to view the patient’s file, 
            diagnose his condition and set a suitable date for treatment.  



        </p>

    </form>





</div>








<?php
include './layout/footer.php';
?>