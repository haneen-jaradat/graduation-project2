<?php

$host = "localhost";
$db = "youvuz_clinic";
$user = "youvuz_clinic";
$password = "UUojZ*_1qD-x";

$connection = mysqli_connect($host, $user, $password, $db) or die("Cannot Connect To database.");




