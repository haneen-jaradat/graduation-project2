</div>



<footer>
    <div id="footer-section">
        <div class="c-1200">
            <div class="top-footer">
                <div class="col-xs-12 col-md-4">
                    <div class="logo"><a href="/"><img src="../../asset/images/logo1.png" alt=""></a></div>
                </div>
                <div class="col-xs-12 col-md-8">
                    <div class="footer-menu">
                        <div class="region region-top-menu">
                            <div class="region region-top-menu">
                                <div id="block-menu-menu-top-menu" class="block block-menu">


                                    <div class="content">
                                        <ul class="menu"><li class="first leaf"><a href="/" title="" class="active">HOME</a></li>
                                            <li><a href="/">HOME</a></li>
                                            <li><a href="./add-dept.php">Add New Department</a></li>
                                            <li><a href="./all-doctor.php">Doctors</a></li>
                                            <li><a href="./logout.php">Logout</a></li>
                                        </ul>  </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="www.instgram.com/"><img src="../../asset/images/instaicon.jpg" alt=""></a>
            </div>

            <div class="bottom-footer">
                <div class="">
                    <div class="copyright">
                        Clinic. All rights reserved <?php echo date('Y') ?> © 
                    </div>
                    
                </div> 

            </div>

        </div>
        <a href="www.instgram.com/"><img src="../../asset/images/instaicon.jpg" alt=""></a>
    </div>
</footer><!-- comment -->


</body>
</html>